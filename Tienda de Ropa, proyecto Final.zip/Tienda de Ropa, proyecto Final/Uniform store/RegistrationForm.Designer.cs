﻿namespace Uniform_store
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.createButtton = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.FirstnametextBox = new System.Windows.Forms.TextBox();
            this.EmailtextBox = new System.Windows.Forms.TextBox();
            this.LnametextBox = new System.Windows.Forms.TextBox();
            this.UserNametextBox = new System.Windows.Forms.TextBox();
            this.PasswordtextBox = new System.Windows.Forms.TextBox();
            this.ConfirmtextBox = new System.Windows.Forms.TextBox();
            this.AlreadyRegisterLink = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.AddresstextBox = new System.Windows.Forms.TextBox();
            this.DiscriptiontextBox = new System.Windows.Forms.TextBox();
            this.FirstNameerrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.LastNameerrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.EmailerrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.UserNameerrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.DiscriptionerrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.AddresserrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.GendererrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.PassworderrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.ConfirmerrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.GendercomboBox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.rolecomboBox = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.RoleerrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.FirstNameerrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LastNameerrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EmailerrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UserNameerrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiscriptionerrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddresserrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GendererrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PassworderrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConfirmerrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RoleerrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // createButtton
            // 
            this.createButtton.BackColor = System.Drawing.Color.Maroon;
            this.createButtton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createButtton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.createButtton.Location = new System.Drawing.Point(3, 475);
            this.createButtton.Margin = new System.Windows.Forms.Padding(2);
            this.createButtton.Name = "createButtton";
            this.createButtton.Size = new System.Drawing.Size(362, 41);
            this.createButtton.TabIndex = 10;
            this.createButtton.Text = "Crear Cuenta";
            this.createButtton.UseVisualStyleBackColor = false;
            this.createButtton.Click += new System.EventHandler(this.createButtton_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Goldenrod;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(13, 0);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(523, 63);
            this.textBox1.TabIndex = 31;
            this.textBox1.Text = "Formulario De Registro";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FirstnametextBox
            // 
            this.FirstnametextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstnametextBox.ForeColor = System.Drawing.Color.Black;
            this.FirstnametextBox.Location = new System.Drawing.Point(94, 76);
            this.FirstnametextBox.Margin = new System.Windows.Forms.Padding(2);
            this.FirstnametextBox.Name = "FirstnametextBox";
            this.FirstnametextBox.Size = new System.Drawing.Size(107, 21);
            this.FirstnametextBox.TabIndex = 0;
            // 
            // EmailtextBox
            // 
            this.EmailtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailtextBox.ForeColor = System.Drawing.Color.Black;
            this.EmailtextBox.Location = new System.Drawing.Point(94, 170);
            this.EmailtextBox.Margin = new System.Windows.Forms.Padding(2);
            this.EmailtextBox.Name = "EmailtextBox";
            this.EmailtextBox.Size = new System.Drawing.Size(327, 21);
            this.EmailtextBox.TabIndex = 3;
            // 
            // LnametextBox
            // 
            this.LnametextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LnametextBox.ForeColor = System.Drawing.Color.Black;
            this.LnametextBox.Location = new System.Drawing.Point(279, 76);
            this.LnametextBox.Margin = new System.Windows.Forms.Padding(2);
            this.LnametextBox.Name = "LnametextBox";
            this.LnametextBox.Size = new System.Drawing.Size(144, 21);
            this.LnametextBox.TabIndex = 1;
            // 
            // UserNametextBox
            // 
            this.UserNametextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserNametextBox.ForeColor = System.Drawing.Color.Black;
            this.UserNametextBox.Location = new System.Drawing.Point(94, 133);
            this.UserNametextBox.Margin = new System.Windows.Forms.Padding(2);
            this.UserNametextBox.Name = "UserNametextBox";
            this.UserNametextBox.Size = new System.Drawing.Size(326, 21);
            this.UserNametextBox.TabIndex = 2;
            // 
            // PasswordtextBox
            // 
            this.PasswordtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordtextBox.ForeColor = System.Drawing.Color.Black;
            this.PasswordtextBox.Location = new System.Drawing.Point(106, 417);
            this.PasswordtextBox.Margin = new System.Windows.Forms.Padding(2);
            this.PasswordtextBox.Name = "PasswordtextBox";
            this.PasswordtextBox.Size = new System.Drawing.Size(326, 21);
            this.PasswordtextBox.TabIndex = 8;
            // 
            // ConfirmtextBox
            // 
            this.ConfirmtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfirmtextBox.ForeColor = System.Drawing.Color.Black;
            this.ConfirmtextBox.Location = new System.Drawing.Point(175, 444);
            this.ConfirmtextBox.Margin = new System.Windows.Forms.Padding(2);
            this.ConfirmtextBox.Name = "ConfirmtextBox";
            this.ConfirmtextBox.Size = new System.Drawing.Size(326, 21);
            this.ConfirmtextBox.TabIndex = 9;
            // 
            // AlreadyRegisterLink
            // 
            this.AlreadyRegisterLink.AutoSize = true;
            this.AlreadyRegisterLink.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AlreadyRegisterLink.Location = new System.Drawing.Point(365, 518);
            this.AlreadyRegisterLink.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.AlreadyRegisterLink.Name = "AlreadyRegisterLink";
            this.AlreadyRegisterLink.Size = new System.Drawing.Size(176, 15);
            this.AlreadyRegisterLink.TabIndex = 11;
            this.AlreadyRegisterLink.TabStop = true;
            this.AlreadyRegisterLink.Text = "¿Ya tiene cuenta? Inicie sesión";
            this.AlreadyRegisterLink.Click += new System.EventHandler(this.AlreadyRegisterLink_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(224, 388);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 18);
            this.label2.TabIndex = 20;
            this.label2.Text = "Género*";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(4, 353);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 15);
            this.label1.TabIndex = 19;
            this.label1.Text = "Fecha de nacimiento";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(149, 353);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(327, 23);
            this.dateTimePicker1.TabIndex = 6;
            // 
            // AddresstextBox
            // 
            this.AddresstextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddresstextBox.ForeColor = System.Drawing.Color.Black;
            this.AddresstextBox.Location = new System.Drawing.Point(96, 280);
            this.AddresstextBox.Margin = new System.Windows.Forms.Padding(2);
            this.AddresstextBox.Multiline = true;
            this.AddresstextBox.Name = "AddresstextBox";
            this.AddresstextBox.Size = new System.Drawing.Size(332, 45);
            this.AddresstextBox.TabIndex = 5;
            // 
            // DiscriptiontextBox
            // 
            this.DiscriptiontextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiscriptiontextBox.ForeColor = System.Drawing.Color.Black;
            this.DiscriptiontextBox.Location = new System.Drawing.Point(97, 207);
            this.DiscriptiontextBox.Margin = new System.Windows.Forms.Padding(2);
            this.DiscriptiontextBox.Multiline = true;
            this.DiscriptiontextBox.Name = "DiscriptiontextBox";
            this.DiscriptiontextBox.Size = new System.Drawing.Size(326, 66);
            this.DiscriptiontextBox.TabIndex = 4;
            // 
            // FirstNameerrorProvider
            // 
            this.FirstNameerrorProvider.ContainerControl = this;
            // 
            // LastNameerrorProvider
            // 
            this.LastNameerrorProvider.ContainerControl = this;
            // 
            // EmailerrorProvider
            // 
            this.EmailerrorProvider.ContainerControl = this;
            // 
            // UserNameerrorProvider
            // 
            this.UserNameerrorProvider.ContainerControl = this;
            // 
            // DiscriptionerrorProvider
            // 
            this.DiscriptionerrorProvider.ContainerControl = this;
            // 
            // AddresserrorProvider
            // 
            this.AddresserrorProvider.ContainerControl = this;
            // 
            // GendererrorProvider
            // 
            this.GendererrorProvider.ContainerControl = this;
            // 
            // PassworderrorProvider
            // 
            this.PassworderrorProvider.ContainerControl = this;
            // 
            // ConfirmerrorProvider
            // 
            this.ConfirmerrorProvider.ContainerControl = this;
            // 
            // GendercomboBox
            // 
            this.GendercomboBox.ForeColor = System.Drawing.Color.Black;
            this.GendercomboBox.FormattingEnabled = true;
            this.GendercomboBox.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.GendercomboBox.Location = new System.Drawing.Point(294, 388);
            this.GendercomboBox.Margin = new System.Windows.Forms.Padding(2);
            this.GendercomboBox.Name = "GendercomboBox";
            this.GendercomboBox.Size = new System.Drawing.Size(127, 21);
            this.GendercomboBox.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(34, 78);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 15);
            this.label3.TabIndex = 32;
            this.label3.Text = "Nombre";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(216, 79);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 15);
            this.label4.TabIndex = 33;
            this.label4.Text = "Apellido";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(39, 171);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 15);
            this.label5.TabIndex = 34;
            this.label5.Text = "Email*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(19, 139);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 15);
            this.label6.TabIndex = 35;
            this.label6.Text = "Usuario*";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(0, 210);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 15);
            this.label7.TabIndex = 36;
            this.label7.Text = "Descripción*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(15, 280);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 15);
            this.label8.TabIndex = 37;
            this.label8.Text = "Dirección*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(10, 420);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 15);
            this.label9.TabIndex = 38;
            this.label9.Text = "*Contraseña*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(14, 444);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(157, 15);
            this.label10.TabIndex = 39;
            this.label10.Text = "*Confirmar contraseña*";
            // 
            // rolecomboBox
            // 
            this.rolecomboBox.ForeColor = System.Drawing.Color.Black;
            this.rolecomboBox.FormattingEnabled = true;
            this.rolecomboBox.Items.AddRange(new object[] {
            "admin",
            "seller"});
            this.rolecomboBox.Location = new System.Drawing.Point(96, 104);
            this.rolecomboBox.Margin = new System.Windows.Forms.Padding(2);
            this.rolecomboBox.Name = "rolecomboBox";
            this.rolecomboBox.Size = new System.Drawing.Size(105, 21);
            this.rolecomboBox.TabIndex = 40;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(39, 107);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 15);
            this.label11.TabIndex = 41;
            this.label11.Text = "Rol";
            // 
            // RoleerrorProvider
            // 
            this.RoleerrorProvider.ContainerControl = this;
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 542);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.rolecomboBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.GendercomboBox);
            this.Controls.Add(this.DiscriptiontextBox);
            this.Controls.Add(this.AddresstextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.AlreadyRegisterLink);
            this.Controls.Add(this.ConfirmtextBox);
            this.Controls.Add(this.PasswordtextBox);
            this.Controls.Add(this.UserNametextBox);
            this.Controls.Add(this.LnametextBox);
            this.Controls.Add(this.EmailtextBox);
            this.Controls.Add(this.FirstnametextBox);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.createButtton);
            this.ForeColor = System.Drawing.Color.Black;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "RegistrationForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegistrationForm";
            this.Load += new System.EventHandler(this.RegistrationForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.FirstNameerrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LastNameerrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EmailerrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UserNameerrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiscriptionerrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddresserrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GendererrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PassworderrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConfirmerrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RoleerrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button createButtton;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox FirstnametextBox;
        private System.Windows.Forms.TextBox EmailtextBox;
        private System.Windows.Forms.TextBox LnametextBox;
        private System.Windows.Forms.TextBox UserNametextBox;
        private System.Windows.Forms.TextBox PasswordtextBox;
        private System.Windows.Forms.TextBox ConfirmtextBox;
        private System.Windows.Forms.LinkLabel AlreadyRegisterLink;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox AddresstextBox;
        private System.Windows.Forms.TextBox DiscriptiontextBox;
        private System.Windows.Forms.ErrorProvider FirstNameerrorProvider;
        private System.Windows.Forms.ErrorProvider LastNameerrorProvider;
        private System.Windows.Forms.ErrorProvider EmailerrorProvider;
        private System.Windows.Forms.ErrorProvider UserNameerrorProvider;
        private System.Windows.Forms.ErrorProvider DiscriptionerrorProvider;
        private System.Windows.Forms.ErrorProvider AddresserrorProvider;
        private System.Windows.Forms.ErrorProvider GendererrorProvider;
        private System.Windows.Forms.ErrorProvider PassworderrorProvider;
        private System.Windows.Forms.ErrorProvider ConfirmerrorProvider;
        private System.Windows.Forms.ComboBox GendercomboBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox rolecomboBox;
        private System.Windows.Forms.ErrorProvider RoleerrorProvider;
    }
}