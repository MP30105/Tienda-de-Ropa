﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Uniform_store
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
        }

        private void Stockbutton_Click(object sender, EventArgs e)
        {
            ViewData viewData = new ViewData();
            viewData.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SalesReport viewData = new SalesReport();
            viewData.Show();
            this.Hide();
        }

        private void Report_Load(object sender, EventArgs e)
        {

        }
    }
}
