﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Uniform_store
{
    public partial class adminForm : Form
    {
        OleDbConnection con = new OleDbConnection();
        public adminForm()
        {
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=./database.mdb";
            InitializeComponent();
            BindGridView();
            GetItems();
        }

        string idProducto;

        private void GetItems()
        {
            CatagorycomboBox.Items.Clear();
           OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=./database.mdb");
            string query = "select * from catagory";
            OleDbCommand cmd = new OleDbCommand(query, con);
            con.Open();
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                string items_names = dr.GetString(1);
                CatagorycomboBox.Items.Add(items_names);
            }
            CatagorycomboBox.Sorted = true;
            con.Close();
        }


        void BindGridView()
        {
           OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=./database.mdb");
            string query = "select * from productTable";
            con.Open();
            OleDbDataAdapter sda = new OleDbDataAdapter(query, con);
            DataTable data = new DataTable();
            sda.Fill(data);
            dataGridView2.DataSource = data;
        }

        private void logoutbutton1_Click(object sender, EventArgs e)
        {
            Login form1 = new Login();
            this.Hide();
            form1.Show();
        }

        private void catagorybutton_Click(object sender, EventArgs e)
        {
            catagoryForm form2 = new catagoryForm();
            this.Hide();
            form2.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SellerForm form3 = new SellerForm();
            this.Hide();
            form3.ShowDialog();
        }

       


        private void Addbutton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(nametextBox.Text) == true)
            {
                MessageBox.Show("Enter the Product Name !!!!!!");
                nametextBox.Focus();
            }
            else if (string.IsNullOrEmpty(PricetextBox.Text) == true)
            {
                MessageBox.Show("Enter the Price");
                PricetextBox.Focus();
            }
            else if(string.IsNullOrEmpty(QuantitytextBox.Text) == true)

            {
                MessageBox.Show("Enter the Quantity");
                QuantitytextBox.Focus();
            }
            else if (string.IsNullOrEmpty(BarcodetextBox.Text) == true)

            {
                MessageBox.Show("Enter the Barcode");
                BarcodetextBox.Focus();
            }
            else if (string.IsNullOrEmpty(CatagorycomboBox.Text) == true)

            {
                MessageBox.Show("Select product Catagory ");
                CatagorycomboBox.Focus();
            }
            else if (string.IsNullOrEmpty(sizecomboBox.Text) == true)

            {
                MessageBox.Show("Select Size ");
                sizecomboBox.Focus();
            }
            else
            {
                try
                {
                    con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=./database.mdb";
                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = con;
                    con.Open();

                    cmd.Parameters.Clear();

                    string query2 = "insert into ProductTable(productbarcode,name,quantity,sizee ,price,cid) values (" + BarcodetextBox.Text + ",'" + nametextBox.Text + "'," + QuantitytextBox.Text + ",'" + sizecomboBox.Text + "'," + PricetextBox.Text + "," + Convert.ToInt32(catagorytextBox.Text) + ")";
                    cmd.CommandText = query2;
                    int a = Convert.ToInt32(cmd.ExecuteNonQuery());
                    if (a > 0)
                    {
                        MessageBox.Show("Insertion Successful", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        catagorytextBox.Clear();
                        
                        idtextBox.Clear();
                        nametextBox.Clear();
                        QuantitytextBox.Clear();
                        PricetextBox.Clear();
                        BarcodetextBox.Clear();
                        BindGridView();

                    }
                    else
                        MessageBox.Show("Insertion Fail", "failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error " + ex);
                }

            }
             
        }



        private void Deletebutton_Click(object sender, EventArgs e)
        {

            Int32 selectedRowCount =
       dataGridView2.Rows.GetRowCount(DataGridViewElementStates.Selected);
            if (selectedRowCount > 0)
            {
                idProducto = dataGridView2.CurrentRow.Cells["productid"].Value.ToString();
                idtextBox.Text = idProducto;

                OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=./database.mdb");
                string query = "delete from productTable where productid=" + idtextBox.Text + "";
                OleDbCommand cmd = new OleDbCommand(query, con);


                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Deleted Successfully", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    catagorytextBox.Clear();
                    idtextBox.Clear();
                    nametextBox.Clear();
                    QuantitytextBox.Clear();
                    PricetextBox.Clear();
                    BarcodetextBox.Clear();

                }

                catch
                {
                    MessageBox.Show("Deletion Fail", "failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                BindGridView();
                con.Close();

            }


        }

        private void Editbutton_Click(object sender, EventArgs e)
        {

            Int32 selectedRowCount =
        dataGridView2.Rows.GetRowCount(DataGridViewElementStates.Selected);
            if (selectedRowCount > 0)
            {
                 idProducto = dataGridView2.CurrentRow.Cells["productid"].Value.ToString();
                 string productbarcode = dataGridView2.CurrentRow.Cells["productbarcode"].Value.ToString();
                 string name = dataGridView2.CurrentRow.Cells["name"].Value.ToString();
                 string quantity = dataGridView2.CurrentRow.Cells["quantity"].Value.ToString();
                 string sizee = dataGridView2.CurrentRow.Cells["sizee"].Value.ToString();
                 string cid = dataGridView2.CurrentRow.Cells["cid"].Value.ToString();
                 string price = dataGridView2.CurrentRow.Cells["price"].Value.ToString();

                idtextBox.Text = idProducto;
                catagorytextBox.Text = cid;
                nametextBox.Text = name;
                BarcodetextBox.Text = productbarcode;
                QuantitytextBox.Text = quantity;
                sizecomboBox.Text = sizee;
                PricetextBox.Text = price;

                BtnSave.Visible = true;
                Editbutton.Visible = false;

            }

            else
            {
                MessageBox.Show("Selecciona una fila");
            }


               
            
        }

        private void CatagorycomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = con;
                string query = "select cid from catagory where cname='" + CatagorycomboBox.Text + "'";
                command.CommandText = query;

                OleDbDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    catagorytextBox.Text = reader["cid"].ToString();

                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }
        }

        private void Clearbutton_Click(object sender, EventArgs e)
        {
            catagorytextBox.Clear();
            idtextBox.Clear();
            nametextBox.Clear();
            QuantitytextBox.Clear();
            PricetextBox.Clear();
            BarcodetextBox.Clear();
            sizecomboBox.DataSource = null;
        }

       

        private void dataGridView2_MouseDoubleClick_1(object sender, MouseEventArgs e)
        {
            idtextBox.Text = dataGridView2.SelectedRows[0].Cells[0].Value.ToString();
            nametextBox.Text = dataGridView2.SelectedRows[0].Cells[2].Value.ToString();
            QuantitytextBox.Text = dataGridView2.SelectedRows[0].Cells[3].Value.ToString();
            PricetextBox.Text = dataGridView2.SelectedRows[0].Cells[5].Value.ToString();
            BarcodetextBox.Text = dataGridView2.SelectedRows[0].Cells[1].Value.ToString();
            sizecomboBox.Text = dataGridView2.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void sizecomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=./database.mdb";
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = con;

            string query = "update  productTable set productbarcode=" + BarcodetextBox.Text + ",name='" + nametextBox.Text.ToString() + "',quantity= " + QuantitytextBox.Text + ",sizee='" + sizecomboBox.Text.ToString() + "', price =" + PricetextBox.Text + " where productid =" + idtextBox.Text + "";

            cmd.CommandText = query;

            con.Open();


                try
                {
                cmd.ExecuteNonQuery();

                MessageBox.Show("Updated Successful", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                catagorytextBox.Clear();
                idtextBox.Clear();
                nametextBox.Clear();
                QuantitytextBox.Clear();
                PricetextBox.Clear();
                BarcodetextBox.Clear();

                BtnSave.Visible = false;
                Editbutton.Visible = true;

                BindGridView();

                }

                catch (Exception ex)
                {
                  MessageBox.Show("" + ex);
                }

               
            
                

            con.Close();

        }

        private void adminForm_Load(object sender, EventArgs e)
        {

        }
    }
}
