﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Uniform_store
{
    public partial class catagoryForm : Form
    {
        OleDbConnection con = new OleDbConnection();
        public catagoryForm()
        {
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=./database.mdb";
            InitializeComponent();
            BindGridView();
        }

        void BindGridView()
        {
           OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=./database.mdb");
            string query = "select * from catagory";
            OleDbDataAdapter sda = new OleDbDataAdapter(query, con);
            DataTable data = new DataTable();
            sda.Fill(data);
            dataGridView1.DataSource = data;
        }

        private void logoutbutton1_Click(object sender, EventArgs e)
        {
            Login form1 = new Login();
            this.Hide();
            form1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SellerForm form3 = new SellerForm();
            this.Hide();
            form3.ShowDialog();
        }

        private void Productbutton_Click(object sender, EventArgs e)
        {

            adminForm form = new adminForm();
            this.Hide();
            form.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            cidtextBox.Text= dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            nametextBox.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            DescriptiontextBox.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();

        }

        private void Addbutton_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(nametextBox.Text) == true)
            {
                MessageBox.Show("Enter the catagory Name !!!!!!");
                nametextBox.Focus();
            }
            
            else if (string.IsNullOrEmpty(DescriptiontextBox.Text) == true)

            {
                MessageBox.Show("Enter Description Catagory ");
                DescriptiontextBox.Focus();
            }
            else
            {
                try
                {
                    OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=./database.mdb");
                    con.Open();
                    string query2 = "insert into catagory(cname,cdescription) values ('" + nametextBox.Text + "','" + DescriptiontextBox.Text + "')";

                    OleDbCommand cmd = new OleDbCommand(query2,con);

                    cmd.ExecuteNonQuery();

           

                    MessageBox.Show("Insertion Successful", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    BindGridView();


                }


                catch (Exception ex)
                {
                    MessageBox.Show("Error " + ex);
                }

            }
        }

        private void Editbutton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(nametextBox.Text) == true)
            {
                MessageBox.Show("Enter the catagory Name !!!!!!");
                nametextBox.Focus();
            }

            else if (string.IsNullOrEmpty(DescriptiontextBox.Text) == true)

            {
                MessageBox.Show("Enter Description Catagory ");
                DescriptiontextBox.Focus();
            }
            else
            {
                try
                {
                    con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=./database.mdb";
                    
  
                    string query2 = "update catagory set cname='" + nametextBox.Text + "',cdescription='" + DescriptiontextBox.Text + "' where cid =" + cidtextBox.Text + " ";


                    con.Open();

                    OleDbCommand cmd = new OleDbCommand(query2,con);


                    cmd.ExecuteNonQuery();

                    MessageBox.Show("update Successful", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cidtextBox.Clear();
                    nametextBox.Clear();
                    DescriptiontextBox.Clear();
                    BindGridView();


                }



                catch(Exception ex)
                {
                    MessageBox.Show(ex + "");
                }

              }

        }

        private void Clearbutton_Click(object sender, EventArgs e)
        {
            cidtextBox.Clear();
            nametextBox.Clear();
            DescriptiontextBox.Clear();
        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=./database.mdb";
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = con;
                string query2 = "delete from catagory where cid =" + cidtextBox.Text + "";
                cmd.CommandText = query2;


                con.Open();

                int a = Convert.ToInt32(cmd.ExecuteNonQuery());
                if (a > 0)
                {
                    MessageBox.Show("Delete Successful", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cidtextBox.Clear();
                    nametextBox.Clear();
                    DescriptiontextBox.Clear();
                    BindGridView();


                }
                else
                    MessageBox.Show("Delete Fail", "failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
            }
        }
    }
}
